# Moses AI Studio — Android starter

This is an Android Studio project (Kotlin + Jetpack Compose) with:
- Home screen and navigation
- AI chat using Google's Gemini REST API
- Android document picker for video/audio files
- Open/preview selected media in compatible apps

## Build an APK
1. Install Android Studio on a computer and open this project folder.
2. Allow Gradle to sync and download dependencies.
3. Choose **Build > Build APK(s)**.
4. The debug APK is normally created under `app/build/outputs/apk/debug/`.

## AI key
Create a Gemini API key through Google AI Studio. In the app, open **AI Chat** and paste the key for testing. Do not publish an app that contains a shared hard-coded key. For a public release, use a backend server to protect keys and add appropriate privacy disclosures.

## Current limitations
This is an MVP starter, not a finished commercial editor. It supports AI text chat and selecting/opening media. Actual in-app video trimming, timeline editing, audio mixing, and exporting are not implemented yet and need a media-processing engine and additional UI. AI requires internet access and may incur provider costs or quota limits.
