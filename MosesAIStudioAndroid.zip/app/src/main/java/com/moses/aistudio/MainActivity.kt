package com.moses.aistudio

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

private val Ink = Color(0xFF101126)
private val Panel = Color(0xFF1B1D38)
private val Violet = Color(0xFF9B87FF)
private val White = Color(0xFFF7F6FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Violet, background = Ink, surface = Panel)) { StudioApp() } }
    }
}

@Composable
fun StudioApp() {
    var tab by remember { mutableStateOf("Home") }
    var apiKey by remember { mutableStateOf("") }
    var prompt by remember { mutableStateOf("") }
    var chat by remember { mutableStateOf(listOf("Moses AI" to "Hi! I'm Moses AI. Ask me a question, or open the Video and Music studios below.")) }
    var pickedUri by remember { mutableStateOf<Uri?>(null) }
    var pickedName by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            pickedUri = uri
            pickedName = uri.lastPathSegment ?: "Selected media"
            try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
        }
    }

    Column(Modifier.fillMaxSize().background(Ink)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 18.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).background(Violet, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.AutoAwesome, null, tint = Ink, modifier = Modifier.size(27.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("MOSES AI STUDIO", color = White, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                Text("Your creative AI workspace", color = Violet, fontSize = 12.sp)
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("Home", "AI Chat", "Video", "Music").forEach { item ->
                FilterChip(selected = tab == item, onClick = { tab = item }, label = { Text(item) })
            }
        }
        when (tab) {
            "Home" -> HomeScreen(onOpen = { tab = it })
            "AI Chat" -> {
                Column(Modifier.weight(1f).padding(16.dp)) {
                    Text("AI ASSISTANT", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("Answers, ideas, explanations and coding help.", color = Color.LightGray)
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(value = apiKey, onValueChange = { apiKey = it }, label = { Text("Gemini API key") },
                        placeholder = { Text("Paste your key here") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Text("For testing. Don't share your key or publish it inside a public app.", color = Color(0xFFFFCC80), fontSize = 11.sp)
                    Spacer(Modifier.height(12.dp))
                    LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(chat) { (who, message) ->
                            Column(Modifier.fillMaxWidth().background(if (who == "You") Color(0xFF28264B) else Panel, RoundedCornerShape(14.dp)).padding(12.dp)) {
                                Text(who, color = Violet, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Spacer(Modifier.height(4.dp)); Text(message, color = White)
                            }
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(value = prompt, onValueChange = { prompt = it }, modifier = Modifier.weight(1f),
                            placeholder = { Text("Ask Moses AI...") }, maxLines = 3)
                        Spacer(Modifier.width(8.dp))
                        Button(enabled = !busy && prompt.isNotBlank(), onClick = {
                            val question = prompt.trim()
                            prompt = ""; chat = chat + ("You" to question); busy = true
                            scope.launch {
                                val answer = askGemini(apiKey, question)
                                chat = chat + ("Moses AI" to answer)
                                busy = false
                            }
                        }) { if (busy) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp) else Icon(Icons.Default.Send, "Send") }
                    }
                }
            }
            "Video" -> MediaScreen("VIDEO STUDIO", "Choose a video, preview it, and open it in a compatible editor for trimming, joining, text, and effects.", pickedName, pickedUri,
                onPick = { filePicker.launch(arrayOf("video/*")) }, onPreview = { openMedia(context, pickedUri) }, isVideo = true)
            "Music" -> MediaScreen("MUSIC STUDIO", "Choose an audio file, preview it, and open it in a compatible editor for cutting, mixing, volume, and effects.", pickedName, pickedUri,
                onPick = { filePicker.launch(arrayOf("audio/*")) }, onPreview = { openMedia(context, pickedUri) }, isVideo = false)
        }
    }
}

@Composable
fun HomeScreen(onOpen: (String) -> Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Spacer(Modifier.height(12.dp))
        Text("Create something\namazing.", color = White, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 40.sp)
        Spacer(Modifier.height(8.dp))
        Text("One app for answers, videos and music.", color = Color.LightGray, fontSize = 16.sp)
        Spacer(Modifier.height(22.dp))
        FeatureCard("AI Assistant", "Ask questions, learn and get ideas.", Icons.Default.AutoAwesome) { onOpen("AI Chat") }
        FeatureCard("Video Studio", "Choose videos and continue editing.", Icons.Default.Movie) { onOpen("Video") }
        FeatureCard("Music Studio", "Open audio files and work on sound.", Icons.Default.MusicNote) { onOpen("Music") }
        Spacer(Modifier.weight(1f))
        Text("MVP preview • Internet required for AI answers", color = Color.Gray, fontSize = 11.sp)
    }
}

@Composable
fun FeatureCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth().padding(vertical = 7.dp), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Violet, modifier = Modifier.size(34.dp))
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) { Text(title, color = White, fontWeight = FontWeight.Bold, fontSize = 17.sp); Text(subtitle, color = Color.LightGray, fontSize = 12.sp) }
            Icon(Icons.Default.ChevronRight, null, tint = Violet)
        }
    }
}

@Composable
fun MediaScreen(title: String, description: String, name: String, uri: Uri?, onPick: () -> Unit, onPreview: () -> Unit, isVideo: Boolean) {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text(title, color = White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp)); Text(description, color = Color.LightGray)
        Spacer(Modifier.height(24.dp))
        Box(Modifier.fillMaxWidth().height(150.dp).background(Panel, RoundedCornerShape(22.dp)), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(if (isVideo) Icons.Default.Movie else Icons.Default.MusicNote, null, tint = Violet, modifier = Modifier.size(48.dp))
                Spacer(Modifier.height(8.dp))
                Text(if (uri == null) "No file selected" else "Media selected", color = White, fontWeight = FontWeight.Bold)
                if (uri != null) Text(name, color = Color.LightGray, fontSize = 11.sp, maxLines = 1)
            }
        }
        Spacer(Modifier.height(16.dp))
        Button(onClick = onPick, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(8.dp)); Text("Choose ${if (isVideo) "video" else "audio"}") }
        OutlinedButton(onClick = onPreview, enabled = uri != null, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(8.dp)); Text("Preview / open media") }
        Spacer(Modifier.height(12.dp))
        Text("Editing note", color = Violet, fontWeight = FontWeight.Bold)
        Text("This starter app selects files and hands them to an installed compatible editor. In-app timeline editing and exporting need a dedicated media-processing engine and are not yet implemented.", color = Color.LightGray, fontSize = 13.sp)
    }
}

suspend fun askGemini(apiKey: String, question: String): String = withContext(Dispatchers.IO) {
    if (apiKey.isBlank()) return@withContext "Add a Gemini API key above to enable AI answers. Keep the key private."
    try {
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=$apiKey")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; connectTimeout = 15000; readTimeout = 30000; doOutput = true
            setRequestProperty("Content-Type", "application/json")
        }
        val body = JSONObject().put("contents", org.json.JSONArray().put(JSONObject().put("parts", org.json.JSONArray().put(JSONObject().put("text", question))))).toString()
        conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val response = (if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream).bufferedReader().use { it.readText() }
        if (conn.responseCode !in 200..299) return@withContext "AI request failed (${conn.responseCode}). Check your API key, quota, and internet connection."
        val json = JSONObject(response)
        json.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
    } catch (e: Exception) { "Couldn't reach the AI service. Check your internet connection and API key, then try again." }
}

fun openMedia(context: android.content.Context, uri: Uri?) {
    if (uri == null) return
    try {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, context.contentResolver.getType(uri) ?: "*/*")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(intent)
    } catch (_: Exception) {
        Toast.makeText(context, "No compatible app found to open this file.", Toast.LENGTH_LONG).show()
    }
}
